module.exports = ({ t, eq, ok, okRes, errRes, makeContext, create, SCHEMA }) => {
  t('[OKR] tổng trọng số > 100% → cảnh báo, vẫn lưu', () => {
    const A = makeContext();
    const r = okRes(A.api('record.save', { table: 'HR_Objective', record: { Employee_id: 'EM-001', Title: 'X', Start_day: '2026-07-01', Weight_pct: 0.9 } }));
    ok(r.warnings.some(w => /trọng số/.test(w)));
  });
};
