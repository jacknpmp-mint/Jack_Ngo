/**
 * 20_Okr.gs — Nghiệp vụ OKR: trọng số mục tiêu ≤ 100%/người, tiến độ KR, dữ liệu tab Dashboard "OKR".
 * Khai báo: providers.hooks ['Okr_hooks_'], providers.checks ['Okr_checks_'], dashboard.providers ['Okr_board_'].
 */
function Okr_hooks_() {
  return {
    HR_Objective: {
      beforeSave: function (rec, ctx) {
        var others = Data_all_('HR_Objective').filter(function (o) {
          // so năm từ cột NGÀY gốc, không dùng cột AUTO Year (công thức có thể trống / #REF!)
          return o.Employee_id === rec.Employee_id && o.Objective_id !== rec.Objective_id &&
            String(o.Start_day).slice(0, 4) === String(rec.Start_day).slice(0, 4);
        });
        var total = Utils_sum_(others, 'Weight_pct') + Utils_num_(rec.Weight_pct);
        if (total > 1.0001) ctx.warnings.push(L_('Tổng trọng số mục tiêu của nhân viên là ', 'Total objective weight for the employee is ') + Math.round(total * 100) + '%.');
      }
    }
  };
}

/** Dữ liệu gọn cho tab Dashboard (client tự lọc / tính tiếp). */
function Okr_board_(year) {
  return {
    objectives: Data_all_('HR_Objective').map(function (o) { return { id: o.Objective_id, emp: o.Employee_id, title: o.Title, st: o.Status, due: o.Due_day, w: Utils_num_(o.Weight_pct) }; }),
    krs: Data_all_('HR_KeyResult').map(function (k) {
      var t = Utils_num_(k.Target);
      return { id: k.KeyResult_id, obj: k.Objective_id, title: k.Title, pct: t ? Utils_num_(k.Actual) / t : null, st: k.Status };
    })
  };
}

/** Điểm lệch riêng → hiện ở Dashboard › Kiểm tra dữ liệu. */
function Okr_checks_() {
  var out = [];
  var byEmp = Utils_groupBy_(Data_all_('HR_Objective'), 'Employee_id');
  Object.keys(byEmp).forEach(function (e) {
    var w = Utils_sum_(byEmp[e], 'Weight_pct');
    if (Math.abs(w - 1) > 0.001) out.push({ level: 'warn', table: 'HR_Employee', id: e, column: 'Weight_pct',
      message: L_('Tổng trọng số mục tiêu = ', 'Total objective weight = ') + Math.round(w * 100) + '%' });
  });
  return out;
}
