/**
 * 01_Config.gs — Cấu hình & lược đồ dữ liệu (schema) của MTH HR · OKR.
 *
 * File này được SINH TỰ ĐỘNG bằng tools/gen_config.py từ MTH_HR_OKR_DB_v1.0.xlsx + tools/app_spec.json.
 * Muốn đổi: sửa tools/app_spec.json (hoặc file xlsx) rồi chạy lại
 *   python3 tools/extract_xlsx.py <file.xlsx> && python3 tools/gen_config.py <file.xlsx>
 * Không sửa tay phần SCHEMA / LISTS (lần sinh sau sẽ ghi đè).
 *
 * Quy ước cột trong SCHEMA:
 *   key: 'PK' | 'FK'      ref: bảng cha của FK; soft: true = mã không tồn tại chỉ CẢNH BÁO
 *   auto: true            cột công thức (xám) — app KHÔNG ghi đè
 *   list: tên danh mục    lấy giá trị từ LISTS (cho phép giá trị khác, chỉ cảnh báo)
 *   required / unique     bắt buộc / không trùng (quan hệ 1 : 0..1)
 *   pct                   lưu dạng tỷ lệ (0.3 = 30%), giao diện nhập theo %
 *   money / format(url|email) / long (ô nhập nhiều dòng) / min / max
 *   calc: { type: 'mul'|'addDays', src, by }  để trống → app tự tính từ cột src và hằng số APP[by]
 * Thuộc tính bảng: label, prefix + idStyle ('year' → XX-2026-001 | 'catalog' → XX-001), pk, display,
 *   labelCols (nhãn trong ô chọn FK), listCols (cột ở trang danh sách), parentFk (FK cha chính — lọc lựa chọn,
 *   đánh số *_no), groupCol, dateCol (lọc theo năm), view360 (có trang 360°).
 */

var APP = {
  "NAME": "MTH HR · OKR",
  "BRAND": "MTH HR",
  "SUBTITLE": [
    "Nhân sự & OKR",
    "People & OKR"
  ],
  "VERSION": "1.0.0",
  "SCHEMA_VERSION": "MTH_HR_OKR_DB_v1.0",
  "MENU_TITLE": "MTH HR App",
  "PREFIX": "HR_",
  "SPREADSHEET_ID": "",
  "TIMEZONE": "Asia/Ho_Chi_Minh",
  "HEADER_ROW": 1,
  "FIRST_DATA_ROW": 2,
  "LOG_SHEET": "HR_Activity_log",
  "LOCK_TIMEOUT_MS": 20000,
  "ALERT_DAYS": 7,
  "ACTIVITY_PAGE_SIZE": 200,
  "FEATURES": {
    "AUTH": true,
    "ACTIVITY": true,
    "ALERTS": true,
    "VIEW360": true
  },
  "STAFF": {
    "table": "HR_Staff",
    "id": "Staff_id",
    "email": "Email",
    "name": "Full_name",
    "access": "Access_level",
    "active": "Active",
    "role": "Role"
  },
  "CONSTS": {}
};

/** Cấp quyền: số lớn hơn = quyền cao hơn. */
var ROLE_LEVEL = { Viewer: 1, Editor: 2, Admin: 3 };

/** Quyền tối thiểu cho từng loại thao tác. */
var PERMISSION = {
  READ: 'Viewer',
  WRITE: 'Editor',
  DELETE: 'Admin',
  CATALOG_WRITE: 'Admin',
  ACTIVITY_READ: 'Editor'
};

/** Bảng danh mục — chỉ Admin được thêm/sửa, giữ cột bắt buộc. */
var CATALOG_TABLES = [
  "HR_Staff",
  "HR_Department"
];

/** Sheet nhật ký thay đổi (08_Activity.gs tự tạo nếu chưa có). */
var ACTIVITY_COLUMNS = ['Log_id', 'Timestamp', 'User_email', 'Staff_id', 'Action',
  'Table_name', 'Record_id', 'Changed_fields', 'Detail'];

/** Menu bên trái: nhóm → mục (route 'entity' = danh sách + 360°; 'catalog' = bảng danh mục; route khác = trang riêng). */
var MENU = [
  {
    "group": [
      "Nhân sự",
      "People"
    ],
    "items": [
      {
        "table": "HR_Employee",
        "icon": "◉"
      }
    ]
  },
  {
    "group": [
      "OKR",
      "OKR"
    ],
    "items": [
      {
        "table": "HR_Objective",
        "icon": "◎"
      },
      {
        "table": "HR_KeyResult",
        "icon": "◇"
      },
      {
        "table": "HR_Task",
        "icon": "☰"
      }
    ]
  },
  {
    "group": [
      "Danh mục",
      "Catalogs"
    ],
    "items": [
      {
        "table": "HR_Department",
        "icon": "▣"
      },
      {
        "table": "HR_Staff",
        "icon": "☺"
      }
    ]
  }
];

/** Cặp ngày [trước, sau] — ngày sau không được sớm hơn ngày trước (áp cho mọi bảng có đủ 2 cột). */
var DATE_ORDER_RULES = [
  [
    "Start_day",
    "Due_day"
  ],
  [
    "Start_day",
    "Done_day"
  ]
];

/** Cảnh báo theo hạn (Notification.gs). */
var ALERT_RULES = [
  {
    "table": "HR_Objective",
    "date": "Due_day",
    "warnDays": 3,
    "doneCol": "Status",
    "doneValues": [
      "Done"
    ],
    "title": [
      "Mục tiêu (O)",
      "Objective"
    ]
  },
  {
    "table": "HR_KeyResult",
    "date": "Due_day",
    "warnDays": 3,
    "doneCol": "Status",
    "doneValues": [
      "Done"
    ],
    "title": [
      "Kết quả then chốt (KR)",
      "Key result"
    ]
  },
  {
    "table": "HR_Task",
    "date": "Due_day",
    "warnDays": 3,
    "doneCol": "Status",
    "doneValues": [
      "Done"
    ],
    "ownerCol": "Owner_id",
    "title": [
      "Công việc",
      "Task"
    ]
  }
];

/** Dashboard dùng chung (05_Dashboard.gs). */
var DASHBOARD = {
  "kpiTables": [
    "HR_Department",
    "HR_Employee",
    "HR_Objective",
    "HR_KeyResult",
    "HR_Task"
  ],
  "metrics": [
    {
      "label": [
        "Mục tiêu mới",
        "New objectives"
      ],
      "table": "HR_Objective",
      "date": "Start_day"
    },
    {
      "label": [
        "Công việc xong",
        "Tasks done"
      ],
      "table": "HR_Task",
      "date": "Done_day"
    }
  ],
  "providers": [
    "Okr_board_"
  ]
};

/** Cột "nên có" thêm vào cờ Thiếu dữ liệu; cột tự tính thêm (10_Form.gs). */
var FORM_NEED_EXTRA = {};
var FORM_CALC_EXTRA = {};

/** Cột tự điền = Staff_id người đang dùng app khi để trống; giá trị mặc định khi thêm mới (04_Entity.gs). */
var AUTO_USER_COLS = {};
var DEFAULTS = {};

/**
 * Điểm nối module riêng (tên hàm toàn cục). Module nghiệp vụ (vd 20_Project.gs) thêm tên hàm của mình vào đây.
 *  HOOK_PROVIDERS   → { bảng: { beforeSave, afterSave, beforeDelete } }   (Entity_hooks_, User_hooks_ luôn có)
 *  ROUTE_PROVIDERS  → { 'module.action': { role, fn } }
 *  RELATED_PROVIDERS(table, record) → giá trị thêm cho form tự điền
 *  ENTITY_EXTRA_PROVIDERS(table, record) → dữ liệu thêm cho trang 360°
 *  ALERT_PROVIDERS(user, p) → [cảnh báo]      CHECK_PROVIDERS() → [điểm lệch dữ liệu]
 */
var HOOK_PROVIDERS = [
  "Entity_hooks_",
  "User_hooks_",
  "Okr_hooks_"
];
var ROUTE_PROVIDERS = [];
var RELATED_PROVIDERS = [];
var ENTITY_EXTRA_PROVIDERS = [];
var ALERT_PROVIDERS = [];
var CHECK_PROVIDERS = [
  "Okr_checks_"
];

var LISTS = {
  "Access_level": [
    "Admin",
    "Editor",
    "Viewer"
  ],
  "YesNo": [
    "Y",
    "N"
  ],
  "Role": [
    "HR",
    "Manager",
    "Staff"
  ],
  "Emp_status": [
    "Probation",
    "Official",
    "Resigned"
  ],
  "OKR_status": [
    "Draft",
    "On track",
    "At risk",
    "Done"
  ],
  "Work_status": [
    "Not started",
    "In progress",
    "Done",
    "Blocked"
  ],
  "Unit": [
    "%",
    "VND",
    "count",
    "hours"
  ]
};

var SCHEMA = {
  "HR_Staff": {
    "label": "Tài khoản",
    "prefix": "ST",
    "idStyle": "catalog",
    "pk": "Staff_id",
    "display": "Full_name",
    "labelCols": [
      "Full_name"
    ],
    "listCols": [
      "Staff_id",
      "Full_name",
      "Role",
      "Email",
      "Phone",
      "Access_level",
      "Active"
    ],
    "parentFk": "",
    "groupCol": "",
    "dateCol": "",
    "view360": false,
    "columns": [
      {
        "name": "Staff_id",
        "type": "string",
        "key": "PK"
      },
      {
        "name": "Full_name",
        "type": "string",
        "required": true
      },
      {
        "name": "Role",
        "type": "string",
        "list": "Role"
      },
      {
        "name": "Email",
        "type": "string",
        "required": true,
        "unique": true,
        "format": "email"
      },
      {
        "name": "Phone",
        "type": "string"
      },
      {
        "name": "Access_level",
        "type": "string",
        "list": "Access_level",
        "required": true
      },
      {
        "name": "Active",
        "type": "string",
        "list": "YesNo",
        "required": true
      }
    ]
  },
  "HR_Department": {
    "label": "Phòng ban",
    "prefix": "DP",
    "idStyle": "catalog",
    "pk": "Department_id",
    "display": "Department_name",
    "labelCols": [
      "Department_name"
    ],
    "listCols": [
      "Department_id",
      "Department_name",
      "Manager_id",
      "Note"
    ],
    "parentFk": "",
    "groupCol": "",
    "dateCol": "",
    "view360": true,
    "columns": [
      {
        "name": "Department_id",
        "type": "string",
        "key": "PK"
      },
      {
        "name": "Department_name",
        "type": "string"
      },
      {
        "name": "Manager_id",
        "type": "string",
        "key": "FK",
        "ref": "HR_Staff"
      },
      {
        "name": "Note",
        "type": "string",
        "long": true
      }
    ]
  },
  "HR_Employee": {
    "label": "Nhân viên",
    "prefix": "EM",
    "idStyle": "catalog",
    "pk": "Employee_id",
    "display": "Full_name",
    "labelCols": [
      "Full_name",
      "Position"
    ],
    "listCols": [
      "Employee_id",
      "Full_name",
      "Department_id",
      "Position",
      "Join_day",
      "Emp_status",
      "Email"
    ],
    "parentFk": "Department_id",
    "groupCol": "",
    "dateCol": "Join_day",
    "view360": true,
    "columns": [
      {
        "name": "Employee_id",
        "type": "string",
        "key": "PK"
      },
      {
        "name": "Full_name",
        "type": "string"
      },
      {
        "name": "Department_id",
        "type": "string",
        "key": "FK",
        "ref": "HR_Department",
        "required": true
      },
      {
        "name": "Position",
        "type": "string"
      },
      {
        "name": "Join_day",
        "type": "date"
      },
      {
        "name": "Emp_status",
        "type": "string",
        "list": "Emp_status"
      },
      {
        "name": "Email",
        "type": "string",
        "format": "email"
      },
      {
        "name": "Year",
        "type": "number",
        "auto": true
      }
    ]
  },
  "HR_Objective": {
    "label": "Mục tiêu (O)",
    "prefix": "OB",
    "idStyle": "year",
    "pk": "Objective_id",
    "display": "Title",
    "labelCols": [
      "Title"
    ],
    "listCols": [
      "Objective_id",
      "Employee_id",
      "Title",
      "Start_day",
      "Due_day",
      "Weight_pct",
      "Status"
    ],
    "parentFk": "Employee_id",
    "groupCol": "",
    "dateCol": "Start_day",
    "view360": true,
    "columns": [
      {
        "name": "Objective_id",
        "type": "string",
        "key": "PK"
      },
      {
        "name": "Employee_id",
        "type": "string",
        "key": "FK",
        "ref": "HR_Employee",
        "required": true
      },
      {
        "name": "Title",
        "type": "string"
      },
      {
        "name": "Start_day",
        "type": "date"
      },
      {
        "name": "Due_day",
        "type": "date"
      },
      {
        "name": "Weight_pct",
        "type": "number",
        "pct": true,
        "min": 0,
        "max": 1
      },
      {
        "name": "Status",
        "type": "string",
        "list": "OKR_status"
      },
      {
        "name": "Year",
        "type": "number",
        "auto": true
      },
      {
        "name": "Quarter",
        "type": "string",
        "auto": true
      }
    ]
  },
  "HR_KeyResult": {
    "label": "Kết quả then chốt (KR)",
    "prefix": "KR",
    "idStyle": "year",
    "pk": "KeyResult_id",
    "display": "Title",
    "labelCols": [
      "Title"
    ],
    "listCols": [
      "KeyResult_id",
      "Objective_id",
      "Title",
      "Target",
      "Actual",
      "Unit",
      "Due_day"
    ],
    "parentFk": "Objective_id",
    "groupCol": "",
    "dateCol": "Due_day",
    "view360": true,
    "columns": [
      {
        "name": "KeyResult_id",
        "type": "string",
        "key": "PK"
      },
      {
        "name": "Objective_id",
        "type": "string",
        "key": "FK",
        "ref": "HR_Objective",
        "required": true
      },
      {
        "name": "Title",
        "type": "string"
      },
      {
        "name": "Target",
        "type": "number"
      },
      {
        "name": "Actual",
        "type": "number"
      },
      {
        "name": "Unit",
        "type": "string",
        "list": "Unit"
      },
      {
        "name": "Due_day",
        "type": "date"
      },
      {
        "name": "Status",
        "type": "string",
        "list": "OKR_status"
      }
    ]
  },
  "HR_Task": {
    "label": "Công việc",
    "prefix": "TS",
    "idStyle": "year",
    "pk": "Task_id",
    "display": "Title",
    "labelCols": [
      "Title"
    ],
    "listCols": [
      "Task_id",
      "KeyResult_id",
      "Owner_id",
      "Title",
      "Start_day",
      "Due_day",
      "Done_day"
    ],
    "parentFk": "KeyResult_id",
    "groupCol": "",
    "dateCol": "Start_day",
    "view360": false,
    "columns": [
      {
        "name": "Task_id",
        "type": "string",
        "key": "PK"
      },
      {
        "name": "KeyResult_id",
        "type": "string",
        "key": "FK",
        "ref": "HR_KeyResult",
        "required": true
      },
      {
        "name": "Owner_id",
        "type": "string",
        "key": "FK",
        "ref": "HR_Staff"
      },
      {
        "name": "Title",
        "type": "string"
      },
      {
        "name": "Start_day",
        "type": "date"
      },
      {
        "name": "Due_day",
        "type": "date"
      },
      {
        "name": "Done_day",
        "type": "date"
      },
      {
        "name": "Status",
        "type": "string",
        "list": "Work_status"
      }
    ]
  }
};

/* ------------------------------------------------------------------ */

/** Trả về định nghĩa bảng; báo lỗi nếu tên bảng không có trong SCHEMA. */
function Config_table_(name) {
  var t = SCHEMA[name];
  if (!t) throw AppError_('NOT_FOUND', L_('Không có bảng "', 'No table "') + name + L_('" trong cấu hình.', '" in the configuration.'));
  return t;
}

/** Map tên cột → định nghĩa cột. */
function Config_columnMap_(name) {
  var map = {};
  Config_table_(name).columns.forEach(function (c) { map[c.name] = c; });
  return map;
}

/** Danh sách [bảng con, cột FK] trỏ tới bảng `parent`. */
function Config_children_(parent) {
  var out = [];
  Object.keys(SCHEMA).forEach(function (t) {
    SCHEMA[t].columns.forEach(function (c) {
      if (c.key === 'FK' && c.ref === parent) out.push({ table: t, column: c.name });
    });
  });
  return out;
}

/** Bản schema gửi xuống trình duyệt (không có gì bí mật, chỉ rút gọn). */
function Config_clientSchema_() {
  var consts = {};
  Object.keys(APP.CONSTS || {}).forEach(function (k) { consts[k] = APP.CONSTS[k]; });
  return { app: { name: APP.NAME, brand: APP.BRAND, subtitle: APP.SUBTITLE, version: APP.VERSION, schema: APP.SCHEMA_VERSION,
      logSheet: APP.LOG_SHEET, features: APP.FEATURES },
    tables: SCHEMA, lists: LISTS, catalogs: CATALOG_TABLES, menu: MENU, staffTable: APP.STAFF.table,
    roles: ROLE_LEVEL, permission: PERMISSION, consts: consts };
}
