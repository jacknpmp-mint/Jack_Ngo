/**
 * 12_Labels.gs — Nhãn song ngữ (SINH TỰ ĐỘNG bằng tools/gen_config.py từ app_spec.json › labels + tools/base_labels.json).
 * Muốn sửa nhãn: sửa app_spec.json rồi sinh lại. Khóa 'Bảng.Cột' ghi đè nhãn chung của cột.
 */

var I18N_TABLES = {
  "HR_Staff": [
    "Tài khoản",
    "User account"
  ],
  "HR_Department": [
    "Phòng ban",
    "Department"
  ],
  "HR_Employee": [
    "Nhân viên",
    "Employee"
  ],
  "HR_Objective": [
    "Mục tiêu (O)",
    "Objective"
  ],
  "HR_KeyResult": [
    "Kết quả then chốt (KR)",
    "Key result"
  ],
  "HR_Task": [
    "Công việc",
    "Task"
  ]
};

var I18N_COLUMNS = {
  "Staff_id": [
    "Mã tài khoản",
    "User ID"
  ],
  "Full_name": [
    "Họ tên",
    "Full name"
  ],
  "Role": [
    "Vai trò",
    "Role"
  ],
  "Email": [
    "Email",
    "Email"
  ],
  "Phone": [
    "Điện thoại",
    "Phone"
  ],
  "Access_level": [
    "Quyền app",
    "App access"
  ],
  "Active": [
    "Đang hoạt động",
    "Active"
  ],
  "Department_id": [
    "Phòng ban",
    "Department"
  ],
  "Department_name": [
    "Tên phòng ban",
    "Department name"
  ],
  "Manager_id": [
    "Trưởng phòng",
    "Manager"
  ],
  "Note": [
    "Ghi chú",
    "Note"
  ],
  "Employee_id": [
    "Mã nhân viên",
    "Employee ID"
  ],
  "Position": [
    "Chức vụ",
    "Position"
  ],
  "Join_day": [
    "Ngày vào làm",
    "Join date"
  ],
  "Emp_status": [
    "Tình trạng",
    "Employment status"
  ],
  "Year": [
    "Năm",
    "Year"
  ],
  "Objective_id": [
    "Mục tiêu",
    "Objective"
  ],
  "HR_Objective.Title": [
    "Mục tiêu",
    "Objective"
  ],
  "Start_day": [
    "Ngày bắt đầu",
    "Start date"
  ],
  "Due_day": [
    "Hạn",
    "Due date"
  ],
  "Weight_pct": [
    "Trọng số",
    "Weight"
  ],
  "Status": [
    "Trạng thái",
    "Status"
  ],
  "Quarter": [
    "Quý",
    "Quarter"
  ],
  "KeyResult_id": [
    "Kết quả then chốt",
    "Key result"
  ],
  "HR_KeyResult.Title": [
    "Kết quả then chốt",
    "Key result"
  ],
  "Target": [
    "Mục tiêu",
    "Target"
  ],
  "Actual": [
    "Thực tế",
    "Actual"
  ],
  "Unit": [
    "Đơn vị",
    "Unit"
  ],
  "Task_id": [
    "Mã công việc",
    "Task ID"
  ],
  "Owner_id": [
    "Người phụ trách",
    "Owner"
  ],
  "HR_Task.Title": [
    "Tên công việc",
    "Task"
  ],
  "Done_day": [
    "Ngày xong",
    "Done on"
  ]
};

var I18N_NOTES_EN = {};
